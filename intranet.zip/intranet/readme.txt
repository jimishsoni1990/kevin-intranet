=== INTRANET ===
Contributors: Jimish Soni
Requires at least: 5.3
Tested up to: 6.2
Requires PHP: 5.6
NOTE: This theme is a wp version of the phoenix html. 
https://prium.github.io/phoenix/v1.12.0/dashboard/project-management.html

== Changelog ==

= 1.0 =
* Released: December 8, 2020