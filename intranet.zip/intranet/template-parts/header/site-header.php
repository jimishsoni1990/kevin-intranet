<?php
/**
 * Displays the site header.
 *
 * @package WordPress
 * @subpackage intranet
 * @since Intranet 1.0
 */

get_template_part( 'template-parts/header/site-nav' );