<?php
/**
 * Displays the site navigation.
 *
 * @package WordPress
 * @subpackage intranet
 * @since Intranet 1.0
 */

get_template_part( 'template-parts/header/navigation-vertical' );
get_template_part( 'template-parts/header/navigation-top' );
