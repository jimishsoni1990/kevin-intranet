<?php
echo $content = get_sub_field( 'text' );